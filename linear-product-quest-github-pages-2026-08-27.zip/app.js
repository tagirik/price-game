const screen = document.getElementById("screen");
const guideDialog = document.getElementById("guideDialog");

const state = {
  step: 0,
  product: null,
  segment: null,
  value: null,
  pricing: null,
  guardrail: null,
  revisionUsed: false
};

const products = {
  contracts: {
    title: "AI-анализ договоров",
    short: "AI-анализ договоров",
    detail: "Находит потенциально опасные условия и помогает быстрее провести юридическую проверку."
  }
};

const segments = {
  small: {
    title: "Небольшая юридическая команда",
    short: "Небольшая команда",
    detail: "Проверяет 20–30 договоров в месяц и хочет заранее понимать расходы.",
    priority: "предсказуемость бюджета"
  },
  enterprise: {
    title: "Корпоративный юридический департамент",
    short: "Корпоративный департамент",
    detail: "Работает с длинными договорами и не может пропускать существенные риски.",
    priority: "качество глубокой проверки"
  },
  agency: {
    title: "Юридический аутсорсер",
    short: "Юридический аутсорсер",
    detail: "Нагрузка меняется от месяца к месяцу, а стоимость нужно переносить на проекты.",
    priority: "гибкость при пиковом спросе"
  }
};

const values = {
  speed: {
    title: "Экономия времени",
    short: "быстрее проверять договоры",
    detail: "Сократить ручную работу и быстрее передавать договор на согласование."
  },
  risk: {
    title: "Снижение риска",
    short: "не пропускать опасные условия",
    detail: "Сделать существенные риски заметными до подписания договора."
  },
  completion: {
    title: "Готовая проверка",
    short: "получать завершённую проверку",
    detail: "Получить понятный разбор договора, с которым можно принять решение."
  }
};

const pricing = {
  access: {
    title: "Доступ",
    phrase: "доступ к AI-анализу",
    detail: "Фиксированная плата за период без счётчика каждой проверки.",
    eventTitle: "Активность оказалась неравномерной",
    eventQuote: "10% клиентов создают большую часть вычислительной нагрузки.",
    eventDetail: "Свобода использования помогает внедрению, но активные команды делают себестоимость непредсказуемой.",
    experiment: "смоделировать распределение использования и проверить восприятие fair use"
  },
  operation: {
    title: "Операция",
    phrase: "каждую завершённую проверку",
    detail: "Клиент платит за понятное действие — анализ одного договора.",
    eventTitle: "Счётчик изменил поведение",
    eventQuote: "Пользователи стали реже перепроверять сложные договоры.",
    eventDetail: "Цена следует за использованием, но каждое дополнительное действие начинает ощущаться как расход.",
    experiment: "проверить, подавляет ли видимый счётчик полезные повторные проверки"
  },
  result: {
    title: "Результат",
    phrase: "подтверждённый результат проверки",
    detail: "Цена привязана к эффекту, а не к внутреннему объёму вычислений.",
    eventTitle: "Результат понимают по-разному",
    eventQuote: "Для клиента результат — решение, а для продукта — сформированный отчёт.",
    eventDetail: "Цена близка к ценности, но стороны должны одинаково понимать момент достижения результата.",
    experiment: "попросить пять клиентов независимо определить, когда проверка считается завершённой"
  }
};

const guardrails = {
  limit: {
    title: "Включённый лимит",
    phrase: "понятный включённый объём",
    detail: "После порога использование останавливается или требует перехода на другой пакет.",
    experiment: "проверить реакцию на остановку полезного сценария в момент достижения лимита"
  },
  addon: {
    title: "Дополнительный пакет",
    phrase: "пакеты дополнительного объёма",
    detail: "Базовое потребление включено, а пиковый объём можно докупить.",
    experiment: "дать клиентам объяснить тариф своими словами и найти потерянные условия"
  },
  deep: {
    title: "Отдельный глубокий режим",
    phrase: "отдельно оплачиваемый глубокий режим",
    detail: "Быстрый анализ входит в основу, длинные и сложные документы проверяются отдельно.",
    experiment: "проверить, видит ли клиент различимую дополнительную ценность глубокого режима"
  }
};

const reactions = {
  access: {
    limit: {
      quote: "Вы обещали свободный доступ. Почему работа остановилась посреди договора?",
      insight: "Обещание свободы сталкивается с жёстким стоп-сигналом.",
      question: "Что важнее сохранить в этой модели: ощущение свободы или абсолютную предсказуемость?"
    },
    addon: {
      quote: "Доступ вроде безлимитный, но почему за активную работу нужно постоянно докупать пакеты?",
      insight: "База проста, но активные пользователи могут воспринимать доплату как скрытое ограничение.",
      question: "Как объяснить дополнительный пакет так, чтобы он не выглядел наказанием за успех?"
    },
    deep: {
      quote: "Чем глубокая проверка отличается от той, за которую мы уже заплатили?",
      insight: "Свобода базового использования сохранена, но границу режимов придётся доказать.",
      question: "Какой наблюдаемый результат поможет клиенту отличить глубокий режим от базового?"
    }
  },
  operation: {
    limit: {
      quote: "Мы уже платим за каждую проверку. Зачем тогда ещё и общий лимит?",
      insight: "Два ограничения делают логику цены тяжёлой для объяснения.",
      question: "Какое из двух ограничений действительно защищает экономику, а какое можно убрать?"
    },
    addon: {
      quote: "Почему одна и та же проверка стоит по-разному до и после окончания пакета?",
      insight: "Рост выручки следует за использованием, но пакет усложняет понятную единицу оплаты.",
      question: "Можно ли сохранить связь цены с использованием без двух параллельных счётчиков?"
    },
    deep: {
      quote: "Мы платим за проверку или за глубину проверки?",
      insight: "Модель отражает разную себестоимость, но создаёт две конкурирующие единицы цены.",
      question: "Какую одну единицу клиент сможет прогнозировать без калькулятора?"
    }
  },
  result: {
    limit: {
      quote: "Если мы платим за результат, почему объём работы ограничен до его получения?",
      insight: "Ограничение внутреннего объёма противоречит обещанию завершённого результата.",
      question: "Как защитить затраты, не перенося внутреннее ограничение на клиента?"
    },
    addon: {
      quote: "Мы покупаем результат или пакет попыток его получить?",
      insight: "Пакет возвращает внимание клиента от эффекта к объёму потребления.",
      question: "Что должно входить в гарантированный результат, а что остаётся дополнительной работой?"
    },
    deep: {
      quote: "Как заранее понять, когда обычной проверки недостаточно?",
      insight: "Цена близка к эффекту, но глубину и результат нужно определить до начала работы.",
      question: "Кто и по какому наблюдаемому признаку выбирает глубокий режим?"
    }
  }
};

function resetState() {
  Object.assign(state, { step: 0, product: null, segment: null, value: null, pricing: null, guardrail: null, revisionUsed: false });
}

function choiceCard(kicker, title, detail, action, value) {
  return `<button class="choice-button" type="button" data-action="${action}" data-value="${value}">
    <span class="choice-kicker">${kicker}</span>
    <strong>${title}</strong>
    <span>${detail}</span>
  </button>`;
}

function progress(step, title) {
  const percent = Math.round((step / 8) * 100);
  return `<div class="progress-wrap">
    <div class="progress-meta"><span>Этап ${step} из 8</span><span>${title}</span></div>
    <div class="progress-track" role="progressbar" aria-label="Прогресс квеста" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}">
      <div class="progress-bar" style="width:${percent}%"></div>
    </div>
  </div>`;
}

function stageExplainer(text) {
  return `<div class="stage-explainer">
    <span class="stage-explainer-label">Что делаем сейчас</span>
    <p>${text}</p>
  </div>`;
}

function contextStrip() {
  const items = [];
  if (state.product) items.push(`<span class="context-chip"><strong>Продукт:</strong> ${products[state.product].short}</span>`);
  if (state.segment) items.push(`<span class="context-chip"><strong>Клиент:</strong> ${segments[state.segment].short}</span>`);
  if (state.value) items.push(`<span class="context-chip"><strong>Ценность:</strong> ${values[state.value].title}</span>`);
  if (state.pricing) items.push(`<span class="context-chip"><strong>Оплата:</strong> ${pricing[state.pricing].title}</span>`);
  if (state.guardrail) items.push(`<span class="context-chip"><strong>Защита:</strong> ${guardrails[state.guardrail].title}</span>`);
  return items.length ? `<div class="context-strip">${items.join("")}</div>` : "";
}

function renderHome() {
  screen.innerHTML = `<div class="hero-grid">
    <div>
      <h1>Собери тариф для AI-продукта</h1>
      <p class="lead">Игра о том, как монетизировать AI-функциональность, не потеряв клиентскую ценность и не сделав экономику продукта неуправляемой.</p>
      <div class="hero-actions">
        <button class="primary-button" type="button" data-action="start">Начать квест · 3–4 минуты</button>
        <button class="secondary-button" type="button" data-action="route">Показать механику команде</button>
      </div>
    </div>
    <aside class="route-card">
      <p class="eyebrow">Роль участника</p>
      <strong>Вы отвечаете за запуск AI-продукта</strong>
      <p>Нужно связать задачу клиента, обещанную ценность, способ оплаты и растущую себестоимость.</p>
      <p><b>Итог:</b> персональная карта гипотезы и вопрос для разговора со стендистом.</p>
    </aside>
  </div>
  <section class="why-section" aria-label="Почему эта тема важна сейчас">
    <p class="eyebrow">Почему эта тема стала особенно острой</p>
    <div class="why-grid">
      <div><strong>AI меняет продукт</strong><span>Новые функции становятся частью привычных сервисов и самостоятельных решений.</span></div>
      <div><strong>Использование создаёт затраты</strong><span>Чем чаще и глубже клиент работает с AI, тем выше переменная себестоимость.</span></div>
      <div><strong>Токены не объясняют цену</strong><span>Клиенту нужна понятная единица ценности, а продукту — управляемая экономика.</span></div>
    </div>
  </section>
  <div class="flow" aria-label="Короткая схема квеста">
    <div class="flow-step"><span class="flow-number">01</span><span class="flow-label">Продукт и клиент</span></div>
    <div class="flow-step"><span class="flow-number">02</span><span class="flow-label">Ценность и единица оплаты</span></div>
    <div class="flow-step"><span class="flow-number">03</span><span class="flow-label">Нагрузка и защита экономики</span></div>
    <div class="flow-step"><span class="flow-number">04</span><span class="flow-label">Реакция рынка и эксперимент</span></div>
  </div>`;
}

function renderRoute() {
  screen.innerHTML = `<p class="eyebrow">Инструкция к механике</p>
    <h2>Одна линия, последствия ветвятся</h2>
    <p class="lead">Все участники проходят одинаковые восемь этапов. Развилки меняют содержание следующего события, поэтому связь между ценностью, тарифом и экономикой остаётся видимой.</p>
    <div class="flow">
      <div class="flow-step"><span class="flow-number">1</span><span class="flow-label">Выбрать продукт</span></div>
      <div class="flow-step"><span class="flow-number">2</span><span class="flow-label">Выбрать клиента</span></div>
      <div class="flow-step"><span class="flow-number">3</span><span class="flow-label">Определить ценность</span></div>
      <div class="flow-step"><span class="flow-number">4</span><span class="flow-label">Выбрать оплату</span></div>
      <div class="flow-step"><span class="flow-number">5</span><span class="flow-label">Увидеть поведение</span></div>
      <div class="flow-step"><span class="flow-number">6</span><span class="flow-label">Защитить экономику</span></div>
      <div class="flow-step"><span class="flow-number">7</span><span class="flow-label">Получить реакцию</span></div>
      <div class="flow-step"><span class="flow-number">8</span><span class="flow-label">Проверить гипотезу</span></div>
      <div class="flow-step"><span class="flow-number">→</span><span class="flow-label">Обсудить со стендистом</span></div>
    </div>
    <div class="decision-summary"><strong>Что показывает прототип:</strong> на этапе выбора видны разные типы AI-продуктов, но сейчас полностью собран только один демонстрационный кейс — «AI-анализ договоров». Этого достаточно, чтобы обсудить механику без преждевременной проработки всего контента.</div>
    <div class="hero-actions">
      <button class="primary-button" type="button" data-action="start">Пройти демонстрационный сценарий</button>
      <button class="secondary-button" type="button" data-action="home">Назад</button>
    </div>`;
}

function renderProduct() {
  state.step = 1;
  screen.innerHTML = `${progress(1, "Выбор продукта")}
    <p class="eyebrow">Точка старта</p>
    <h2>Какой AI-продукт запускаем?</h2>
    ${stageExplainer("Выбираем продукт, экономику которого будем разбирать. В финальной игре здесь могут быть разные сценарии, но для демонстрации команде сейчас подробно собран только один.")}
    <div class="choice-grid">
      ${choiceCard("Демо-сценарий готов", products.contracts.title, products.contracts.detail, "product", "contracts")}
      <button class="choice-button choice-button-disabled" type="button" disabled>
        <span class="choice-kicker">Возможный сценарий позже</span><strong>AI-помощник маркетолога</strong><span>Пока показываем как будущий вариант, без проработки веток.</span>
      </button>
      <button class="choice-button choice-button-disabled" type="button" disabled>
        <span class="choice-kicker">Возможный сценарий позже</span><strong>AI-агент поддержки</strong><span>Пока показываем как будущий вариант, без проработки веток.</span>
      </button>
    </div>`;
}

function renderSegment() {
  state.step = 2;
  screen.innerHTML = `${progress(2, "Клиент")}${contextStrip()}
    <p class="eyebrow">Кому продаём первым</p>
    <h2>Кого запускаем первым?</h2>
    ${stageExplainer("Один продукт создаёт разную ценность и разную нагрузку в разных сегментах. Выбираем первого клиента, чтобы дальше принимать решения в конкретном контексте.")}
    <div class="choice-grid">
      ${Object.entries(segments).map(([id, item]) => choiceCard(item.priority, item.title, item.detail, "segment", id)).join("")}
    </div>`;
}

function renderValue() {
  state.step = 3;
  screen.innerHTML = `${progress(3, "Клиентская ценность")}${contextStrip()}
    <p class="eyebrow">Обещание продукта</p>
    <h2>Какую ценность ставим в центр?</h2>
    ${stageExplainer("Фиксируем главное обещание клиенту. Позже именно оно должно объяснить, почему тариф устроен так, а не иначе.")}
    <div class="choice-grid">
      ${Object.entries(values).map(([id, item]) => choiceCard("Ценность", item.title, item.detail, "value", id)).join("")}
    </div>`;
}

function renderPricing() {
  state.step = 4;
  screen.innerHTML = `${progress(4, "Модель оплаты")}${contextStrip()}
    <p class="eyebrow">Гипотеза монетизации</p>
    <h2>За что платит клиент?</h2>
    ${stageExplainer("Переводим внутреннюю AI-экономику в понятную клиенту единицу оплаты. Клиент не должен разбираться в токенах и вычислениях, чтобы понимать цену.")}
    <div class="choice-grid">
      ${Object.entries(pricing).map(([id, item]) => choiceCard("Единица оплаты", item.title, item.detail, "pricing", id)).join("")}
    </div>`;
}

function renderLoadEvent() {
  state.step = 5;
  const item = pricing[state.pricing];
  screen.innerHTML = `${progress(5, "Первый месяц")}${contextStrip()}
    <div class="event-layout">
      <div class="event-visual">
        <span class="event-icon" aria-hidden="true">↗</span>
        <div><p class="eyebrow">Через месяц после запуска</p><p class="event-quote">${item.eventQuote}</p></div>
      </div>
      <div>
        <h2>${item.eventTitle}</h2>
        ${stageExplainer("Смотрим, как выбранная модель оплаты изменила реальное поведение пользователей и себестоимость после запуска. Это последствие вашего решения, а не случайная проверка.")}
        <p class="lead event-explanation">${item.eventDetail}</p>
        <div class="decision-summary">Это последствие возникло из выбранной единицы оплаты — оно не было известно заранее.</div>
        <div class="hero-actions"><button class="primary-button" type="button" data-action="continue-guardrail">Защитить экономику</button></div>
      </div>
    </div>`;
}

function renderGuardrail() {
  state.step = 6;
  screen.innerHTML = `${progress(6, "Защита экономики")}${contextStrip()}
    <p class="eyebrow">Ответ на нагрузку</p>
    <h2>Как контролируем дорогой сценарий?</h2>
    ${stageExplainer("Выбираем способ контролировать дорогие сценарии использования. Задача — сделать затраты управляемыми, не наказывая клиента за получение ценности.")}
    <div class="choice-grid">
      ${Object.entries(guardrails).map(([id, item]) => choiceCard("Механизм", item.title, item.detail, "guardrail", id)).join("")}
    </div>`;
}

function renderReaction() {
  state.step = 7;
  const reaction = reactions[state.pricing][state.guardrail];
  screen.innerHTML = `${progress(7, "Реакция рынка")}${contextStrip()}
    <div class="event-layout">
      <div class="event-visual alert">
        <span class="event-icon" aria-hidden="true">“</span>
        <div><p class="eyebrow">Пилотный клиент</p><p class="event-quote">${reaction.quote}</p></div>
      </div>
      <div>
        <h2>Тариф встретился с реальностью</h2>
        ${stageExplainer("Слышим реакцию пилотного клиента на собранный тариф. Можно сохранить гипотезу для проверки или один раз изменить решение после обратной связи.")}
        <p class="lead">${reaction.insight}</p>
        <div class="decision-summary"><strong>Вопрос:</strong> ${reaction.question}</div>
        <div class="hero-actions">
          <button class="primary-button" type="button" data-action="finish">Оставить как гипотезу</button>
          <button class="secondary-button" type="button" data-action="revise">Изменить одно решение</button>
        </div>
      </div>
    </div>`;
}

function renderRevision() {
  screen.innerHTML = `${progress(7, "Одна корректировка")}${contextStrip()}
    <p class="eyebrow">Решение после обратной связи</p>
    <h2>Можно изменить только один элемент</h2>
    ${stageExplainer("Меняем только одну часть тарифа. Так мы не ищем магическую правильную комбинацию, а осознанно выбираем, какое противоречие готовы проверять дальше.")}
    <div class="revision-grid">
      <section class="revision-group">
        <h3>Единица оплаты</h3>
        <div class="revision-options">
          ${Object.entries(pricing).map(([id, item]) => `<button class="revision-option" type="button" data-action="revise-pricing" data-value="${id}" ${id === state.pricing ? "disabled" : ""}>${item.title}</button>`).join("")}
        </div>
      </section>
      <section class="revision-group">
        <h3>Защита экономики</h3>
        <div class="revision-options">
          ${Object.entries(guardrails).map(([id, item]) => `<button class="revision-option" type="button" data-action="revise-guardrail" data-value="${id}" ${id === state.guardrail ? "disabled" : ""}>${item.title}</button>`).join("")}
        </div>
      </section>
    </div>
    <div class="hero-actions"><button class="secondary-button" type="button" data-action="reaction">Не менять</button></div>`;
}

function signals() {
  const valueSignal = state.pricing === "result" ? "сильная опора" : "нужно доказать";
  const freedomSignal = state.guardrail === "deep" || state.pricing === "access" ? "сохранена" : "под риском";
  const economySignal = state.guardrail === "limit" || state.guardrail === "deep" ? "понятный контур" : "нужна модель";
  return { valueSignal, freedomSignal, economySignal };
}

function renderResult() {
  state.step = 8;
  const segment = segments[state.segment];
  const value = values[state.value];
  const price = pricing[state.pricing];
  const guard = guardrails[state.guardrail];
  const reaction = reactions[state.pricing][state.guardrail];
  const status = signals();
  screen.innerHTML = `${progress(8, "Карта гипотезы")}
    ${stageExplainer("Собираем всю цепочку решений в одну проверяемую гипотезу. Финальный вопрос нужен не для оценки игрока, а для короткого содержательного разговора со стендистом.")}
    <div class="result-layout">
      <section class="hypothesis-card">
        <p class="eyebrow">Ваша гипотеза запуска</p>
        <p class="hypothesis-formula">Для сегмента <strong>«${segment.short}»</strong> продукт помогает <strong>${value.short}</strong>. Клиент платит за <strong>${price.phrase}</strong>, а затраты контролируются через <strong>${guard.phrase}</strong>.</p>
        <ul class="insight-list">
          <li><strong>Сильная сторона:</strong> решение учитывает приоритет «${segment.priority}» и переводит техническую экономику в клиентские условия.</li>
          <li><strong>Главное противоречие:</strong> ${reaction.insight}</li>
          <li><strong>Первый эксперимент:</strong> ${state.revisionUsed ? guard.experiment : price.experiment}.</li>
        </ul>
      </section>
      <aside class="debrief-card">
        <p class="eyebrow">Разговор со стендистом · 60 секунд</p>
        <p class="debrief-question">${reaction.question}</p>
        <p>Задача стендиста — обсудить одно решение, а не объяснять участнику всю теорию монетизации.</p>
        <div class="signal-list">
          <div class="signal-row"><span>Клиентская ценность</span><strong>${status.valueSignal}</strong></div>
          <div class="signal-row"><span>Свобода использования</span><strong>${status.freedomSignal}</strong></div>
          <div class="signal-row"><span>Контроль экономики</span><strong>${status.economySignal}</strong></div>
        </div>
        <div class="hero-actions"><button class="primary-button" type="button" data-action="restart">Новая сессия</button></div>
      </aside>
    </div>`;
}

function route(action, value) {
  switch (action) {
    case "home": resetState(); renderHome(); break;
    case "route": renderRoute(); break;
    case "guide": guideDialog.showModal(); break;
    case "start": renderProduct(); break;
    case "product": state.product = value; renderSegment(); break;
    case "segment": state.segment = value; renderValue(); break;
    case "value": state.value = value; renderPricing(); break;
    case "pricing": state.pricing = value; renderLoadEvent(); break;
    case "continue-guardrail": renderGuardrail(); break;
    case "guardrail": state.guardrail = value; renderReaction(); break;
    case "revise": renderRevision(); break;
    case "reaction": renderReaction(); break;
    case "revise-pricing": state.pricing = value; state.revisionUsed = true; renderResult(); break;
    case "revise-guardrail": state.guardrail = value; state.revisionUsed = true; renderResult(); break;
    case "finish": renderResult(); break;
    case "restart": resetState(); renderProduct(); break;
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.addEventListener("click", (event) => {
  const target = event.target.closest("[data-action]");
  if (!target) return;
  route(target.dataset.action, target.dataset.value);
});

renderHome();
